package com.expensetracker.app.parser

data class ParsedTransaction(
    val amount: Double,
    val merchant: String,
    val accountRef: String,
    val category: String,
    val isCredit: Boolean = false,
    val rawText: String
)
