package com.expensetracker.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.expensetracker.app.data.AppDatabase
import com.expensetracker.app.data.Expense
import com.expensetracker.app.parser.SmsParser
import com.expensetracker.app.worker.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // Combine multi-part SMS messages from the same sender
        val fullBodyBuilder = StringBuilder()
        for (sms in messages) {
            sms.displayMessageBody?.let { fullBodyBuilder.append(it) }
        }
        val fullBody = fullBodyBuilder.toString()
        Log.d("SmsReceiver", "Received SMS: \$fullBody")

        // Parse with SmsParser
        val parsed = SmsParser.parse(fullBody) ?: return

        Log.i("SmsReceiver", "Parsed transaction: Amount=\${parsed.amount}, Merchant=\${parsed.merchant}")

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val expense = Expense(
                    amount = parsed.amount,
                    merchant = parsed.merchant,
                    category = parsed.category,
                    accountRef = parsed.accountRef,
                    rawMessage = parsed.rawText,
                    isCredit = parsed.isCredit
                )
                db.expenseDao().insert(expense)

                // Optional: Show quick transaction receipt notification
                NotificationHelper.showTransactionReceipt(
                    context = context,
                    amount = parsed.amount,
                    merchant = parsed.merchant,
                    category = parsed.category
                )
            } catch (e: Exception) {
                Log.e("SmsReceiver", "Failed to store parsed expense", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
