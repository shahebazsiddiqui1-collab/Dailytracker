package com.expensetracker.app.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.expensetracker.app.data.AppDatabase
import java.util.Calendar

class DailySummaryWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        Log.i("DailySummaryWorker", "Executing daily end-of-day expense calculation...")

        return try {
            val db = AppDatabase.getDatabase(applicationContext)

            // Calculate start and end of current day
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            val startOfDay = calendar.timeInMillis

            calendar.set(Calendar.HOUR_OF_DAY, 23)
            calendar.set(Calendar.MINUTE, 59)
            calendar.set(Calendar.SECOND, 59)
            val endOfDay = calendar.timeInMillis

            val totalSpent = db.expenseDao().getTotalSpentBetweenSync(startOfDay, endOfDay) ?: 0.0
            val count = db.expenseDao().getTransactionCountBetweenSync(startOfDay, endOfDay)

            Log.i("DailySummaryWorker", "Today's Total Spent: \$totalSpent across \$count transactions.")

            // Send push notification
            NotificationHelper.showDailySummaryNotification(
                context = applicationContext,
                totalSpent = totalSpent,
                count = count
            )

            Result.success()
        } catch (e: Exception) {
            Log.e("DailySummaryWorker", "Failed to compute daily summary", e)
            Result.retry()
        }
    }
}
