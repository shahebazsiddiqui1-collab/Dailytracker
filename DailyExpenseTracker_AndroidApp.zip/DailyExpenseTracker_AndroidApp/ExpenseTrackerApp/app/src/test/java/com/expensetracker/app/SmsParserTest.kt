package com.expensetracker.app

import com.expensetracker.app.parser.SmsParser
import org.junit.Assert.*
import org.junit.Test

class SmsParserTest {

    @Test
    fun testHdfcDebitSms() {
        val sms = "Dear Customer, INR 450.00 debited from A/c XX1234 on 12-Nov-26 to SWIGGY. UPI Ref 342123."
        val result = SmsParser.parse(sms)
        assertNotNull(result)
        assertEquals(450.0, result!!.amount, 0.001)
        assertEquals("SWIGGY", result.merchant)
        assertEquals("XX1234", result.accountRef)
        assertEquals("Food & Dining", result.category)
        assertFalse(result.isCredit)
    }

    @Test
    fun testIciciCardSpend() {
        val sms = "Rs 1,299.00 spent on your ICICI Bank Card XX5001 on 12-Nov-26 at AMAZON INDIA. Avl Lmt: Rs 45,000."
        val result = SmsParser.parse(sms)
        assertNotNull(result)
        assertEquals(1299.0, result!!.amount, 0.001)
        assertEquals("AMAZON", result.merchant)
        assertEquals("XX5001", result.accountRef)
        assertEquals("Shopping", result.category)
    }

    @Test
    fun testUpiPaymentToChaiPoint() {
        val sms = "Paid Rs. 85.00 to CHAI POINT via UPI transaction ID 987654321."
        val result = SmsParser.parse(sms)
        assertNotNull(result)
        assertEquals(85.0, result!!.amount, 0.001)
        assertEquals("CHAI POINT", result.merchant)
        assertEquals("Food & Dining", result.category)
    }

    @Test
    fun testUberTripDebit() {
        val sms = "Txn of INR 850.00 done on Card ending 9012 at UBER TRIP on 12-Nov-26."
        val result = SmsParser.parse(sms)
        assertNotNull(result)
        assertEquals(850.0, result!!.amount, 0.001)
        assertEquals("UBER TRIP", result.merchant)
        assertEquals("Travel & Transport", result.category)
    }

    @Test
    fun testSalaryCreditIgnored() {
        val sms = "Dear Customer, your A/c ending 1234 credited by INR 75,000.00 on 01-Nov-26 by SALARY transfer."
        val result = SmsParser.parse(sms)
        assertNull("Salary credit should be ignored for expense tracking", result)
    }
}
