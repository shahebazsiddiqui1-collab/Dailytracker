package com.expensetracker.app.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF0F9D58)
val GreenDark = Color(0xFF0B8043)
val GreenLight = Color(0xFFE8F5E9)

val RedExpense = Color(0xFFD32F2F)
val RedLight = Color(0xFFFFEBEE)

val SurfaceDark = Color(0xFF1E1E2E)
val SurfaceLight = Color(0xFFF8F9FA)

val TextPrimary = Color(0xFF202124)
val TextSecondary = Color(0xFF5F6368)
