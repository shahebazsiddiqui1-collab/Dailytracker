package com.expensetracker.app.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun SmsSimulatorDialog(
    onDismiss: () -> Unit,
    onSimulate: (rawSms: String) -> Unit
) {
    var customSms by remember { mutableStateOf("") }

    val sampleSmsList = listOf(
        "HDFC: INR 450.00 debited from A/c XX1234 on 12-Nov-26 to SWIGGY. UPI Ref 342123.",
        "ICICI: Rs 1,299.00 spent on your Bank Card XX5001 on 12-Nov-26 at AMAZON INDIA.",
        "SBI: Paid Rs. 85.00 to CHAI POINT via UPI Ref 987654321.",
        "Axis: Txn of INR 850.00 done on Card ending 9012 at UBER TRIP.",
        "A/c 9876 debited by Rs.2,400.00 on 12/11/26 by Transfer to ZOMATO."
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "SMS Transaction Simulator",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Test automatic SMS parsing instantly by clicking a bank template or entering custom text.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "Quick Presets:",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )

                LazyColumn(
                    modifier = Modifier.heightIn(max = 200.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(sampleSmsList) { sms ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { customSms = sms }
                        ) {
                            Text(
                                text = sms,
                                modifier = Modifier.padding(8.dp),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = customSms,
                    onValueChange = { customSms = it },
                    label = { Text("Bank SMS Body") },
                    placeholder = { Text("Paste SMS here...") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (customSms.isNotBlank()) {
                                onSimulate(customSms)
                            }
                        },
                        enabled = customSms.isNotBlank()
                    ) {
                        Text("Simulate Parsing")
                    }
                }
            }
        }
    }
}
