package com.expensetracker.app.worker

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

object WorkScheduler {

    private const val WORK_TAG_DAILY_SUMMARY = "work_daily_expense_summary"
    private const val WORK_TAG_INSTANT_TEST = "work_instant_summary_test"

    /**
     * Schedules a recurring WorkManager job that fires daily at 9:00 PM (21:00)
     */
    fun scheduleDailySummaryWorker(context: Context) {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 21) // 9:00 PM
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If it is already past 9 PM today, schedule for 9 PM tomorrow
        if (now.after(target)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }

        val initialDelay = target.timeInMillis - now.timeInMillis

        val dailyWorkRequest = PeriodicWorkRequestBuilder<DailySummaryWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
            .addTag(WORK_TAG_DAILY_SUMMARY)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_TAG_DAILY_SUMMARY,
            ExistingPeriodicWorkPolicy.UPDATE,
            dailyWorkRequest
        )
    }

    /**
     * Triggers an immediate one-off calculation and notification for testing
     */
    fun triggerInstantSummaryTest(context: Context) {
        val oneTimeWork = OneTimeWorkRequestBuilder<DailySummaryWorker>()
            .addTag(WORK_TAG_INSTANT_TEST)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            WORK_TAG_INSTANT_TEST,
            ExistingWorkPolicy.REPLACE,
            oneTimeWork
        )
    }
}
