package com.expensetracker.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amount: Double,
    val merchant: String,
    val category: String,
    val accountRef: String,
    val timestamp: Long = System.currentTimeMillis(),
    val rawMessage: String,
    val isCredit: Boolean = false
)
