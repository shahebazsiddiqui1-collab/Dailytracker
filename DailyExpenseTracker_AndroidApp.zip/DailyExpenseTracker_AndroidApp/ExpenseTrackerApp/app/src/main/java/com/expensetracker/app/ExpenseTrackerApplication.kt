package com.expensetracker.app

import android.app.Application
import com.expensetracker.app.data.AppDatabase
import com.expensetracker.app.worker.NotificationHelper
import com.expensetracker.app.worker.WorkScheduler

class ExpenseTrackerApplication : Application() {

    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
        
        // 1. Initialize Notification Channels
        NotificationHelper.createNotificationChannel(this)

        // 2. Schedule Daily 9:00 PM Spending Summary Worker
        WorkScheduler.scheduleDailySummaryWorker(this)
    }
}
