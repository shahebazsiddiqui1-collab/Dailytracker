package com.expensetracker.app.parser

import java.util.regex.Pattern

object SmsParser {

    private val CREDIT_PATTERN = Pattern.compile(
        "\\b(credited|credit|received|deposited|refunded|refund|cashback|added to)\\b",
        Pattern.CASE_INSENSITIVE
    )

    private val DEBIT_PATTERN = Pattern.compile(
        "\\b(debited|spent|paid|sent|withdrawn|charged|txn of|purchase of|transferred|transfer to|payment to|payment of|purchase at)\\b",
        Pattern.CASE_INSENSITIVE
    )

    // Match currency prefixes: INR, Rs., Rs, ₹, USD, $, EUR
    private val AMOUNT_PATTERN_PREFIX = Pattern.compile(
        "(?:INR|Rs\\.?|₹|USD|\\$|EUR)\\s*([0-9]+(?:,[0-9]{2,3})*(?:\\.[0-9]{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )

    // Match currency suffix: 450.00 INR
    private val AMOUNT_PATTERN_SUFFIX = Pattern.compile(
        "([0-9]+(?:,[0-9]{2,3})*(?:\\.[0-9]{1,2})?)\\s*(?:INR|Rs\\.?|₹|USD|EUR)",
        Pattern.CASE_INSENSITIVE
    )

    // Account / Card reference
    private val ACCOUNT_PATTERN = Pattern.compile(
        "\\b(?:a/c|acct|account|card|ending)\\s*(?:no\\.?)?\\s*(?:ending\\s*)?(?:in\\s*)?([xX*]*[0-9]{4})\\b",
        Pattern.CASE_INSENSITIVE
    )

    // Merchant patterns
    private val MERCHANT_PATTERNS = listOf(
        Pattern.compile("\\b(?:transfer to|transferred to|paid to|sent to|payment to)\\s+([A-Za-z0-9\\s\\.\\&\\@\\-\\_]{2,30}?)(?=[,\\.]?(?:\\s+(?:on|via|ref|upi|avl|bal|using|card|ac|a/c|from|with|successful|by|in)|[,\\.]|$))", Pattern.CASE_INSENSITIVE),
        Pattern.compile("\\b(?:at|towards|vpa|info)\\s+([A-Za-z0-9\\s\\.\\&\\@\\-\\_]{2,30}?)(?=[,\\.]?(?:\\s+(?:on|via|ref|upi|avl|bal|using|card|ac|a/c|from|with|successful|by|in)|[,\\.]|$))", Pattern.CASE_INSENSITIVE),
        Pattern.compile("\\bto\\s+([A-Za-z0-9\\s\\.\\&\\@\\-\\_]{2,30}?)(?=[,\\.]?(?:\\s+(?:on|via|ref|upi|avl|bal|using|card|ac|a/c|from|with|successful|by|in)|[,\\.]|$))", Pattern.CASE_INSENSITIVE)
    )

    // Category mappings
    private val CATEGORY_RULES = mapOf(
        "Food & Dining" to listOf("swiggy", "zomato", "mcdonalds", "starbucks", "kfc", "dominos", "pizza", "burger", "cafe", "restaurant", "dining", "chai", "coffee"),
        "Groceries" to listOf("blinkit", "zepto", "instamart", "bigbasket", "dmart", "grocery", "supermarket", "nature's basket"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio", "zara", "h&m", "retail", "mart"),
        "Travel & Transport" to listOf("uber", "ola", "rapido", "irctc", "makemytrip", "indigo", "airindia", "metro", "fuel", "petrol", "shell", "hpcl", "bpcl"),
        "Entertainment" to listOf("netflix", "spotify", "bookmyshow", "hotstar", "prime", "cinema", "theatre", "pvr", "inox"),
        "Bills & Utilities" to listOf("bescom", "airtel", "jio", "vi", "vodafone", "broadband", "water", "gas", "electricity", "bill", "recharge")
    )

    fun parse(smsBody: String): ParsedTransaction? {
        val cleanBody = smsBody.replace("\n", " ").trim()

        val isCredit = CREDIT_PATTERN.matcher(cleanBody).find()
        val isDebit = DEBIT_PATTERN.matcher(cleanBody).find()

        // Skip credit messages if they don't indicate a debit/expense
        if (isCredit && !isDebit) {
            return null
        }

        // 1. Extract Amount
        var amount: Double? = null
        val prefixMatcher = AMOUNT_PATTERN_PREFIX.matcher(cleanBody)
        if (prefixMatcher.find()) {
            amount = prefixMatcher.group(1)?.replace(",", "")?.toDoubleOrNull()
        } else {
            val suffixMatcher = AMOUNT_PATTERN_SUFFIX.matcher(cleanBody)
            if (suffixMatcher.find()) {
                amount = suffixMatcher.group(1)?.replace(",", "")?.toDoubleOrNull()
            }
        }

        if (amount == null || amount <= 0.0) {
            return null
        }

        // 2. Extract Account Reference
        var accountRef = "Primary A/c"
        val accMatcher = ACCOUNT_PATTERN.matcher(cleanBody)
        if (accMatcher.find()) {
            accountRef = accMatcher.group(1)?.uppercase() ?: "Primary A/c"
        }

        // 3. Extract Merchant / Payee
        var merchant = "Unknown Merchant"
        for (pattern in MERCHANT_PATTERNS) {
            val mMatcher = pattern.matcher(cleanBody)
            if (mMatcher.find()) {
                val candidate = mMatcher.group(1)?.trim()
                    ?.replace(Regex("^(the|a|an)\\s+", RegexOption.IGNORE_CASE), "")
                    ?.trim(' ', '.', ',', ';', ':', '-')
                
                if (!candidate.isNullOrBlank() && 
                    candidate.length >= 2 && 
                    !candidate.matches(Regex("^(account|a/c|card|your|bank|atm)$", RegexOption.IGNORE_CASE))) {
                    merchant = candidate.uppercase()
                    break
                }
            }
        }

        // 4. Categorize
        val mLower = merchant.lowercase()
        val bLower = cleanBody.lowercase()
        var category = "Other"

        for ((catName, keywords) in CATEGORY_RULES) {
            if (keywords.any { mLower.contains(it) || bLower.contains(it) }) {
                category = catName
                break
            }
        }

        return ParsedTransaction(
            amount = amount,
            merchant = merchant,
            accountRef = accountRef,
            category = category,
            isCredit = isCredit && !isDebit,
            rawText = cleanBody
        )
    }
}
