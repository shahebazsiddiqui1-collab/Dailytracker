# 📱 Daily Expense Tracker (Android)

An intelligent, privacy-first Android app built with **Kotlin**, **Jetpack Compose (Material 3)**, **Room Database**, and **WorkManager** that automatically logs daily expenses by parsing incoming bank transaction SMS and sends a comprehensive daily spending summary notification every evening at **9:00 PM**.

---

## ✨ Key Features

1. **Automatic Transaction SMS Interceptor**:
   - `SmsReceiver` listens for incoming banking SMS (`android.provider.Telephony.SMS_RECEIVED`).
   - `SmsParser` extracts the exact debited amount, merchant/payee name, account/card ending digits, and assigns an automatic category (Food & Dining, Groceries, Shopping, Travel, Bills, Entertainment).
   - Intelligently ignores credit messages (salary, refunds, cashbacks) so they don't inflate your spending total.

2. **9:00 PM Daily Spending Notification**:
   - Uses Android **WorkManager** (`DailySummaryWorker`) scheduled with `PeriodicWorkRequest` to execute every evening at **9:00 PM**.
   - Aggregates the total spending and transaction count for the current day from SQLite/Room.
   - Posts a high-priority heads-up push notification:
     > *"🌙 Daily Spending Summary: You spent a total of ₹1,250.00 across 3 transactions today."*
   - Includes a **BootReceiver** so scheduled notifications persist automatically across phone reboots.

3. **Modern Jetpack Compose UI**:
   - **Hero Card**: Live daily spending total in large currency format with transaction badges.
   - **Real-Time Stream**: Chronological list of today's expenses with category color icons and merchant details.
   - **SMS Simulator Dialog**: Quickly test incoming bank SMS messages from HDFC, SBI, ICICI, Axis, Starbucks, or custom messages right in the app without needing a real SMS!
   - **Instant Notification Test**: Trigger the 9:00 PM notification immediately via a button in the app to preview the notification experience.
   - **Manual Expense Dialog**: Add cash or non-SMS expenses seamlessly.

4. **100% On-Device & Private**:
   - Zero internet permission required! All SMS parsing and database storage happens completely offline in Room DB on the device.

---

## 🛠️ Tech Stack & Architecture

- **Language**: Kotlin 1.9.23
- **UI Toolkit**: Jetpack Compose with Material Design 3
- **Database**: Room Persistence Library with Kotlin Coroutines & Flow
- **Background Scheduling**: AndroidX WorkManager (Guaranteed execution even in Doze mode)
- **Architecture**: Clean Architecture / MVVM (`ViewModel`, `Dao`, `Repository`, `Worker`, `Receiver`)
- **Target SDK**: Android 14 (API 34) | **Min SDK**: Android 8.0 (API 26)

---

## 🚀 How to Run in Android Studio

1. **Unzip the Project**:
   Extract `DailyExpenseTracker_AndroidApp.zip` to a folder on your computer.

2. **Open in Android Studio**:
   - Open Android Studio (Hedgehog, Iguana, Jellyfish, or newer).
   - Click **Open** and select the extracted `ExpenseTrackerApp` folder.
   - Let Gradle sync dependencies.

3. **Run on Emulator or Device**:
   - Select your target device or emulator (Android 8.0+ / API 26+) and click **Run (▶)**.

4. **Grant Permissions**:
   - When the app launches, grant **SMS** (`RECEIVE_SMS`) and **Notification** (`POST_NOTIFICATIONS`) permissions.

5. **Testing**:
   - **In-App Simulator**: Tap the SMS icon in the top app bar and select any bank sample or paste an SMS.
   - **Android Studio SMS Emulator**: Go to the **Extended Controls (...)** on your Android Emulator -> **Phone** -> type an SMS (e.g. `INR 450.00 debited from A/c XX1234 to SWIGGY.`) -> click **Send SMS**. The app will immediately track it in real time!
   - **Notification Preview**: Tap the bell icon in the top app bar to immediately trigger the summary notification.
