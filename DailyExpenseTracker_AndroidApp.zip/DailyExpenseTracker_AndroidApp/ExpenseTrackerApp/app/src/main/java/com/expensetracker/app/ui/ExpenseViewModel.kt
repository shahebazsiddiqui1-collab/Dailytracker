package com.expensetracker.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.expensetracker.app.data.AppDatabase
import com.expensetracker.app.data.Expense
import com.expensetracker.app.parser.SmsParser
import com.expensetracker.app.worker.WorkScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val expenseDao = AppDatabase.getDatabase(application).expenseDao()

    private val startOfDay: Long
        get() {
            val c = Calendar.getInstance()
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

    private val endOfDay: Long
        get() {
            val c = Calendar.getInstance()
            c.set(Calendar.HOUR_OF_DAY, 23)
            c.set(Calendar.MINUTE, 59)
            c.set(Calendar.SECOND, 59)
            return c.timeInMillis
        }

    // Today's total spending
    val todayTotalSpent: StateFlow<Double?> = expenseDao.getTotalSpentBetween(startOfDay, endOfDay)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Today's transaction list
    val todayExpenses: StateFlow<List<Expense>> = expenseDao.getExpensesBetween(startOfDay, endOfDay)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All transactions
    val allExpenses: StateFlow<List<Expense>> = expenseDao.getAllExpenses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addManualExpense(amount: Double, merchant: String, category: String) {
        viewModelScope.launch {
            val expense = Expense(
                amount = amount,
                merchant = merchant.ifBlank { "Manual Entry" },
                category = category,
                accountRef = "Cash/Manual",
                rawMessage = "Manual user entry"
            )
            expenseDao.insert(expense)
        }
    }

    fun simulateIncomingSms(rawSms: String): Boolean {
        val parsed = SmsParser.parse(rawSms) ?: return false
        viewModelScope.launch {
            val expense = Expense(
                amount = parsed.amount,
                merchant = parsed.merchant,
                category = parsed.category,
                accountRef = parsed.accountRef,
                rawMessage = parsed.rawText,
                isCredit = parsed.isCredit
            )
            expenseDao.insert(expense)
        }
        return true
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.delete(expense)
        }
    }

    fun triggerTestNotification() {
        WorkScheduler.triggerInstantSummaryTest(getApplication())
    }
}
