package com.expensetracker.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.expensetracker.app.worker.WorkScheduler

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Re-schedule daily 9:00 PM summary worker after reboot
            WorkScheduler.scheduleDailySummaryWorker(context)
        }
    }
}
