package com.expensetracker.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: Expense): Long

    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Query("SELECT * FROM expenses WHERE timestamp >= :startTime AND timestamp <= :endTime ORDER BY timestamp DESC")
    fun getExpensesBetween(startTime: Long, endTime: Long): Flow<List<Expense>>

    @Query("SELECT SUM(amount) FROM expenses WHERE isCredit = 0 AND timestamp >= :startTime AND timestamp <= :endTime")
    fun getTotalSpentBetween(startTime: Long, endTime: Long): Flow<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE isCredit = 0 AND timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun getTotalSpentBetweenSync(startTime: Long, endTime: Long): Double?

    @Query("SELECT COUNT(*) FROM expenses WHERE isCredit = 0 AND timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun getTransactionCountBetweenSync(startTime: Long, endTime: Long): Int

    @Delete
    suspend fun delete(expense: Expense)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteById(id: Long)
}
